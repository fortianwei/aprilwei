$(function(){
	$('pre').addClass('prettyprint linenums');
	prettyPrint();
	responsive_iframes();
});